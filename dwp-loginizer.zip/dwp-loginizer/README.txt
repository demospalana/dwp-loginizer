=== DWP Loginizer ===

Contributors: demospalana
Tags: login: custom login, dwp loginizer, loginizer, branding
Donate Link: https://www.paypal.com/us/cgi-bin/webscr?cmd=_flow&SESSION=U20uFP6rSAt4pTEZY8WzOt83irUZH5uOV81pmeeI9VgAFTqbhpu1UqvpS1O&dispatch=5885d80a13c0db1f8e263663d3faee8d64813b57e559a2578463e58274899069
Licence: GPL version 2 or later 
Licence URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
Requires at least: 4.0
Tested up to: 4.5
Stable tag: trunk

==Short Description==
Customize your wordpress default login page, change logo, color and more.
==Description==
DWP Loginizer allows you to customize the default wordpress login page.
**DWP Loginizer Features**
*Change Background color.
*Set Image as Background
*Change Text color
*Hide Logo / Change logo
*Change Form Background Color
*Set Form Background Color Opacity / Transparency
*Set Image as Form Background
*Change Button Text Color, Background Color, Border Color
*Add your custom css
** COMING SOON**
*Login Redirect
*Create your own login page with form builder
**SUGGESTIONS**
If you have ideas or you want to add a new feature kindly contact me @ demospalana@yahoo.com
==Installation==
1. Upload the plugin to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Settings > DWP Loginizer and edit your settings.
4. Click the 'Save Changes' button.
== Screenshots ==
1. Design Settings Screen
2. Custom CSS Screen

